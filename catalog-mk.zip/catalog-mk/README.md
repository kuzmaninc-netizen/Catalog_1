# catalog.mk – Онлајн каталог со нарачка преку Viber

Vite + React + Tailwind CSS фронтенд и Base44 (Deno/TypeScript) бекенд.

## Структура

```
catalog-mk/
├── base44/
│   ├── entities/
│   │   ├── Store.json          # шема: name, slug, logo_url, phone, viber_phone, delivery_fee …
│   │   └── Product.json        # шема: store_id, name, price, image_url, category …
│   └── functions/storeApi/
│       └── entry.ts            # акција `publicStore`
├── public/
│   ├── logo-circle.png         # catalog.mk лого – мобилен
│   └── logo-wordmark.png       # catalog.mk лого – десктоп
└── src/
    ├── api/                    # Base44 клиент, publicStore повик, демо податоци
    ├── components/             # Header, ProductCard, CheckoutSheet, CartBar …
    ├── context/CartContext.jsx # кошничка (зачувана по продавница)
    ├── pages/Storefront.jsx
    └── utils/orderMessage.js   # normalizePhone, buildOrderMessage, buildViberUrl
```

## Локално стартување

```bash
npm install
cp .env.example .env      # VITE_USE_MOCK=true за демо без Base44
npm run dev
```

Отворете `http://localhost:5173/pekara-zito` (или `/?store=pekara-zito`).

## Base44

1. Креирајте ги ентитетите `Store` и `Product` според JSON шемите во `base44/entities`.
2. Поставете ја функцијата `base44/functions/storeApi/entry.ts`.
3. Во `.env` поставете `VITE_BASE44_APP_ID` и `VITE_USE_MOCK=false`.

Повик:

```js
base44.functions.invoke('storeApi', { action: 'publicStore', slug: 'pekara-zito' });
```

Одговор:

```json
{
  "ok": true,
  "data": {
    "store": {
      "name": "Пекара Жито",
      "logo_url": "https://…",
      "phone": "38970123456",
      "phone_display": "070 123 456",
      "viber_phone": "38970123456",
      "delivery_fee": 100,
      "free_delivery_from": 1000,
      "min_order": 300
    },
    "products": [{ "id": "…", "name": "Бел леб", "price": 45, "image_url": "https://…", "category": "Леб" }],
    "categories": ["Леб"]
  }
}
```

## Viber

`buildViberUrl('070 123 456', порака)` → `viber://chat?number=38970123456&draft=…`

Телефонот на продавницата во базата може да биде во кој било формат
(`070 123 456`, `+389 70 123 456`, `0038970123456`): серверот и клиентот го нормализираат.

> Viber deep-link работи само на уреди со инсталиран Viber. Затоа по испраќањето
> се прикажува и копија од пораката со копче „Копирај“ како резервна опција.
