import Storefront from './pages/Storefront';
import { DEMO_SLUG } from './api/mockStore';

/**
 * Едноставно рутирање без дополнителни библиотеки:
 *   https://catalog.mk/pekara-zito       → slug = "pekara-zito"
 *   https://catalog.mk/?store=pekara-zito → slug = "pekara-zito"
 *   https://catalog.mk/                   → демо продавница
 */
function getSlugFromLocation() {
  const params = new URLSearchParams(window.location.search);
  const fromQuery = params.get('store');
  if (fromQuery) return fromQuery.trim().toLowerCase();

  const firstSegment = window.location.pathname.split('/').filter(Boolean)[0];
  if (firstSegment) return decodeURIComponent(firstSegment).trim().toLowerCase();

  return DEMO_SLUG;
}

export default function App() {
  const slug = getSlugFromLocation();
  return <Storefront slug={slug} />;
}
