import { createClient } from '@base44/sdk';

const appId = import.meta.env.VITE_BASE44_APP_ID;

/**
 * Јавен Base44 клиент – каталогот не бара најава.
 */
export const base44 = appId
  ? createClient({
      appId,
      requiresAuth: false,
    })
  : null;
