import { base44 } from './base44Client';
import { getMockStore } from './mockStore';

const FUNCTION_NAME = import.meta.env.VITE_BASE44_FUNCTION || 'storeApi';
const USE_MOCK = import.meta.env.VITE_USE_MOCK === 'true' || !base44;

export class StoreApiError extends Error {
  constructor(message, code = 'UNKNOWN', status = 0) {
    super(message);
    this.name = 'StoreApiError';
    this.code = code;
    this.status = status;
  }
}

/**
 * Ја повикува акцијата `publicStore` на Base44 функцијата.
 *
 * @param {string} slug
 * @returns {Promise<{store: object, products: object[], categories: string[]}>}
 */
export async function fetchPublicStore(slug) {
  if (USE_MOCK) {
    // Мала латенција за реалистичен loading state
    await new Promise((r) => setTimeout(r, 350));
    const data = getMockStore(slug);
    if (!data) throw new StoreApiError('Продавницата не е пронајдена.', 'STORE_NOT_FOUND', 404);
    return data;
  }

  try {
    const response = await base44.functions.invoke(FUNCTION_NAME, {
      action: 'publicStore',
      slug,
    });
    const body = response?.data ?? response;

    if (!body?.ok) {
      throw new StoreApiError(
        body?.error?.message || 'Грешка при вчитување на продавницата.',
        body?.error?.code,
        response?.status,
      );
    }
    return body.data;
  } catch (err) {
    if (err instanceof StoreApiError) throw err;

    const status = err?.response?.status ?? err?.status ?? 0;
    const apiError = err?.response?.data?.error;
    throw new StoreApiError(
      apiError?.message ||
        (status === 404
          ? 'Продавницата не е пронајдена.'
          : 'Не можевме да ја вчитаме продавницата. Проверете ја интернет врската.'),
      apiError?.code || (status === 404 ? 'STORE_NOT_FOUND' : 'NETWORK_ERROR'),
      status,
    );
  }
}
