/**
 * Демо податоци во ист формат како одговорот од `publicStore`.
 * Се користат кога VITE_USE_MOCK=true или нема VITE_BASE44_APP_ID.
 */

const img = (seed) => `https://picsum.photos/seed/${seed}/600/600`;

const STORES = {
  'pekara-zito': {
    store: {
      id: 'store_demo_1',
      name: 'Пекара Жито',
      slug: 'pekara-zito',
      description: 'Свежо печиво секое утро. Достава низ Карпош и Центар.',
      logo_url: null,
      cover_url: null,
      address: 'ул. Партизанска бр. 12',
      city: 'Скопје',
      working_hours: 'Пон–Саб 06:00–21:00',
      currency: 'MKD',
      currency_label: 'ден.',
      delivery_fee: 100,
      free_delivery_from: 1000,
      min_order: 300,
      phone: '38970123456',
      phone_display: '070 123 456',
      phone_tel: 'tel:+38970123456',
      viber_phone: '38970123456',
      viber_phone_display: '070 123 456',
    },
    products: [
      { id: 'p1', name: 'Бел леб 500г', description: 'Секојдневен бел леб, печен утрово.', price: 45, image_url: img('bread-white'), category: 'Леб', unit: 'парче', in_stock: true, sort_order: 1 },
      { id: 'p2', name: 'Интегрален леб', description: 'Со семки од сончоглед и лен.', price: 70, image_url: img('bread-whole'), category: 'Леб', unit: 'парче', in_stock: true, sort_order: 2 },
      { id: 'p3', name: 'Багет', description: 'Хрскав француски багет.', price: 55, image_url: img('baguette'), category: 'Леб', unit: 'парче', in_stock: true, sort_order: 3 },
      { id: 'p4', name: 'Бурек со сирење', description: 'Традиционален бурек, порција 300г.', price: 120, image_url: img('burek'), category: 'Пециво', unit: 'парче', in_stock: true, sort_order: 4 },
      { id: 'p5', name: 'Кроасан со чоколадо', description: 'Путер тесто и белгиско чоколадо.', price: 80, image_url: img('croissant'), category: 'Пециво', unit: 'парче', in_stock: true, sort_order: 5 },
      { id: 'p6', name: 'Ѓеврек', description: 'Со сусам, свеж од фурна.', price: 30, image_url: img('simit'), category: 'Пециво', unit: 'парче', in_stock: false, sort_order: 6 },
      { id: 'p7', name: 'Торта Шварцвалд', description: 'Цела торта за 10–12 лица.', price: 1450, image_url: img('cake-black'), category: 'Слатко', unit: 'парче', in_stock: true, sort_order: 7 },
      { id: 'p8', name: 'Баклава', description: 'Домашна баклава со ореви.', price: 650, image_url: img('baklava'), category: 'Слатко', unit: 'кг', in_stock: true, sort_order: 8 },
    ],
  },
};

export function getMockStore(slug) {
  const data = STORES[slug] ?? STORES['pekara-zito'];
  if (!data) return null;
  const categories = Array.from(new Set(data.products.map((p) => p.category)));
  return { ...data, categories };
}

export const DEMO_SLUG = 'pekara-zito';
